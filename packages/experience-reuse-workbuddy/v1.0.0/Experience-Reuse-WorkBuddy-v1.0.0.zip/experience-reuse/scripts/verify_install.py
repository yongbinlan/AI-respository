"""Read-only package and optional routing-text checks; does not prove host activation."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys


def check(root, rule_file=None):
    root=Path(root).expanduser().resolve()
    if '.agents' in [p.casefold() for p in root.parts]:
        raise ValueError('Refusing other-agent directory')
    manifest=json.loads((root/'package-manifest.json').read_text(encoding='utf-8-sig'))
    if manifest.get('schema_version')!=1 or not isinstance(manifest.get('files'),list):
        raise ValueError('Invalid package manifest')
    errors=[]
    names=set()
    for entry in manifest['files']:
        name=entry['path']
        parts=PurePosixPath(name).parts
        if not parts or PurePosixPath(name).is_absolute() or '..' in parts or '\\' in name or any(':' in p for p in parts) or name in names:
            raise ValueError('Unsafe or duplicate package path')
        names.add(name)
        target=root.joinpath(*parts).resolve()
        if not target.is_relative_to(root):
            raise ValueError('Package file escapes root')
        if not target.is_file():
            errors.append({'path':name,'reason':'missing'})
        elif hashlib.sha256(target.read_bytes()).hexdigest()!=entry['sha256']:
            errors.append({'path':name,'reason':'content_mismatch'})
    if 'SKILL.md' not in names or 'scripts/praxis.py' not in names:
        raise ValueError('Manifest lacks required entry points')
    rule_result='not_checked'
    if rule_file is not None:
        rule=Path(rule_file).expanduser()
        if not rule.is_absolute():raise ValueError('Rule path must be absolute')
        rule=rule.resolve()
        if '.agents' in [p.casefold() for p in rule.parts]:raise ValueError('Refusing other-agent rule path')
        text=rule.read_text(encoding='utf-8-sig')
        normalized=text.replace('\\','/').casefold()
        wanted=str(root/'SKILL.md').replace('\\','/').casefold()
        valid=text.count('<!-- experience-reuse:start -->')==1 and text.count('<!-- experience-reuse:end -->')==1 and '<EXPERIENCE_REUSE_SKILL_MD>' not in text and wanted in normalized
        if valid:rule_result='text_matches_installed_path'
        else:
            rule_result='invalid_or_unresolved'
            errors.append({'path':str(rule),'reason':'routing_text_mismatch'})
    return {'ok':not errors,'python_supported':sys.version_info>=(3,10),'skill_path':str(root/'SKILL.md'),'files_checked':len(names),'errors':errors,'routing_text':rule_result,'host_discovery':'not_verified','host_enabled':'not_verified','automatic_new_session_reuse':'not_verified','read_only':True}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skill-root',default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument('--rule-file')
    args=parser.parse_args(argv)
    try:
        if sys.version_info<(3,10):raise ValueError('Python 3.10+ required')
        result=check(args.skill_root,args.rule_file)
    except (ValueError,OSError,KeyError,TypeError) as error:
        result={'ok':False,'error':str(error),'read_only':True,'host_discovery':'not_verified','automatic_new_session_reuse':'not_verified'}
    print(json.dumps(result,ensure_ascii=False))
    return 0 if result['ok'] else 2


if __name__=='__main__':sys.exit(main())
