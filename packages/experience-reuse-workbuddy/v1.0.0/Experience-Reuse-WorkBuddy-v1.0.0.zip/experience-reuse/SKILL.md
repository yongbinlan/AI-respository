---
name: experience-reuse
description: 'Capture a newly created skill''s first verified successful task; also trigger before repeating prior work: previously handled / re-read / continue / same issue / 之前处理过 / 重新读取 / 上次 / 续办, including read-only requests to inspect a named skill, file, tool or site. Apply catalog-first path checks or scoped experience reuse; unrelated one-off reads do not trigger it.'
display_name: 经验复用
display_name_en: Experience Reuse
description_zh: 首次成功后保存经验，后续相关任务自动核条件并复用。
description_en: Capture first verified success and apply scoped experience in later related tasks.
version: 1.0.0
author: yongbinlan
examples_zh:
- 上次完成过这项任务，请继续处理新批次。
- 按这个新建技能处理首个任务并核验结果。
examples_en:
- Continue the next batch of the task handled before.
- Run the new skill on its first real task and verify the result.
---

# Experience Reuse

在重复工作第一次行动前落实已有信息。用户级维护方法，经验保留在所属项目，原生记忆提供线索；稳定步骤归原专业 Skill 或工具。

## 触发与加载

- 用户提到“之前处理过、重新读取、上次、继续、同样问题”等先前工作，并要求对已命名的 Skill、文件、工具、站点或流程采取行动时，在首次相关操作前加载本 Skill 一次；只读说明也适用。
- “不运行目标 Skill 的制作流程”只限制目标业务流程，不排除这里的只读前置检查。不要等到再次失败才加载，也不要用泛化记忆搜索替代它。
- 用户纠正、失败后重试/改路、发现有效新方法时也介入；与历史无关的单次普通读取不必介入。
- 新创建的 Skill 首次执行真实任务并通过结果验证后，也在任务收尾前加载本 Skill 一次，按 [首次成功留存](references/workflow.md#首次成功留存) 保存带条件的成功经验；无需用户提醒，也不以此前失败、第二次使用或出现续办措辞为前提。安装、语法检查或仅命令退出成功不算首次任务成功。

## 准确目录的只读短路径

本 Skill 已加载且任务给出了准确的目录引用时，直接解析并读取目标：不做本 Skill 自行追加的记忆搜索，不查全库、不执行目标制作流程、不创建经验记录。若宿主更高优先级的原生记忆协议要求 quick pass，遵循它并复用结果，不再重复搜索；没有命中也不阻断明确目录的读取。

使用本 Skill 的 `scripts/read_skill.py`，从当前任务复制根映射和目标引用：

```text
python -X utf8 <本Skill目录>/scripts/read_skill.py --root r0=<任务给定项目技能根> --root r1=<任务给定用户技能根> --reference r0/<目标技能>/SKILL.md
```

工具只按给定目录定位，未知别名、目录越界、文件不存在即报错；不猜用户级路径或其他后备位置。成功返回 `ok=true`、`activation=experience-reuse.catalog-first`、实际 `resolved_path` 和目标全文。核对真实输出后完成原只读任务，无新增经验就停止。

## 其他经验任务

短路径不适用时，读取 [完整经验闭环](references/workflow.md)，按原来源检索、核条件、采用、验结果、维护及定向沉淀。需要结构化索引时使用 `scripts/praxis.py`，先读 [工具与协同契约](references/integration.md)。不要为一次查询创建索引；已有权威来源以引用为主。

## 边界与验证

两工具为 Python 3.10+ 标准库，离线且不调用模型。只读解析器不写文件；索引只写显式项目内。原生记忆是历史线索，当前有效指令和权威原文决定行为；不编辑生成记忆、复制原始聊天或未经授权跨项目传播规则。凭据、登录验证、费用、固定专业岗位和原审核门不变；不隐式增加 Hooks、后台任务或模型切换。

入口是模型侧路由，并非宿主级拦截。以新会话中真实加载顺序、解析器调用、首次目标路径和实际结果验收；安装和内部评分不算自动触发。报告实际输入、缓存/未缓存、输出与调用次数，不用缓存差异假称收益；未做可比测试仍为 `savings_unverified`。

## WorkBuddy 宿主适配

这是独立 WorkBuddy 版，不依赖 Codex 安装目录或 agents/openai.yaml。以当前 WorkBuddy 的实际技能目录为准，禁止猜另一台电脑的用户名或复用其他 Agent 私有目录。安装与自动触发配置见 [WorkBuddy 安装说明](references/workbuddy-setup.md)。可选索引仅在显式目标项目 `.codebuddy/experience-reuse/experiences.json` 内保存；优先保留原任务权威回执。本包没有携带任何旧项目经验。
