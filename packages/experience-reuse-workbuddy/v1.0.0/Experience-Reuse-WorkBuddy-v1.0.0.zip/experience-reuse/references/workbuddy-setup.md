# WorkBuddy 安装与协同

1. 将完整 ZIP 复制到目标电脑；从 WorkBuddy 的“技能 → 添加技能 → 上传技能”导入。官方当前说明明确：自制上传包用上传入口；对话市场搜索不是本包的安装方式。导入后在“已安装”确认启用，并让 WorkBuddy 解析实际安装路径。
2. 持久化触发另用本版本真正加载的用户级规则/主指令。官方说明 WorkBuddy 代码任务兼容用户级 `~/.codebuddy/` 和项目 `.codebuddy/` 配置，但这不能证明所有版本的普通办公对话都加载相同文件。不要猜 `~/.workbuddy`、`~/.codebuddy` 或 Codex 路径；以本机发现和新会话回读为准。
3. 读取 routing-template.md，把 `<EXPERIENCE_REUSE_SKILL_MD>` 替换为安装后的真实绝对路径，只合并标记块；保存受影响规则原版，保留其他内容。若已有同名块，比较后更新原块，避免两个入口打架。需要用户操作规则设置时指出具体位置。只有项目级能力时就报告项目级，不能称全局默认生效。
4. 原生记忆负责召回线索；本 Skill 在行动时核对来源与条件。新经验归当前项目/任务，优先原回执；可选索引为 `<实际项目>/.codebuddy/experience-reuse/experiences.json`。首次成功也留存，但用户审核、规则正式晋级和发布授权均不自动成立。不要直接写入 WorkBuddy 生成的记忆数据库；静态用户触发规则与生成记忆是不同对象。
5. 两个 Python 工具离线、无第三方依赖、无模型/API 调用。正常 WorkBuddy Agent 的模型使用仍按本机现有账户/计费；本包不移植 Codex 订阅。先检测 `python`/`python3`/`py -3` 的实际版本，再用真实 Python 3.10+ 执行。

在实际 Skill 目录运行：

```text
python -X utf8 -m unittest discover -s tests -v
python -X utf8 examples/demo.py
python -X utf8 scripts/verify_install.py
```

规则是一个实际本地文件时，可追加 `--rule-file <已确认自动加载的规则文件绝对路径>`。检查器只读，不会安装、编辑规则、创建经验或启动模型；其通过仅证明包内容及规则文本，不能证明 WorkBuddy 已加载/启用或自动触发。

## 新会话验收

安装后由目标 WorkBuddy 的正常新会话完成 A/B。A 的业务任务只要求实际处理并核验，不点名 Experience Reuse、不要求“保存经验”；B 只说“上次处理过这个项目，请继续处理新输入”，不点名任何 Skill，也不给经验文件路径。证据需出现 A 自行写记录、B 实际读记录并核条件、首次采用与新结果验证。不要从本文的示意条件推断测试已通过。本包未在目标机器的 WorkBuddy 做过上述端到端测试。

## 回滚

技能管理中可关闭该 Skill；移除此次添加的规则标记块并保留其余规则。如果技能管理卸载会删除技能文件，先保留需要的包/备份。不要删除项目经验记录，不恢复整份旧配置覆盖后续其他修改。跨机器复制经验库不在此次安装范围内，索引也会拒绝直接继承其他项目根。

## 核实的官方来源（2026-11-27）

- [本地技能包上传](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)
- [技能 ZIP 结构与 frontmatter](https://open.workbuddy.cn/docs/skill)
- [项目 .codebuddy 配置与优先级](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Project)
- [WorkBuddy 设置及用户级配置](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Setting)

CodeBuddy/企业文档的加载细节仅作该配置分支参考；不能替代对实际 WorkBuddy 版本/任务类型的观察。
