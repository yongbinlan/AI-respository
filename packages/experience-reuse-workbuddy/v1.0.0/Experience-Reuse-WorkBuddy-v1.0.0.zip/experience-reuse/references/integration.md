# 本地工具与协同契约

## 数据归属

`--project` 必须是实际项目根目录；不从终端 cwd 推断，不把临时预览目录当项目。项目已有经验/故障/任务接口时先复用。只有本项目没有合适的结构化经验入口，或需要一个到现有原文的简短索引时，才使用本地记录。

工具的写入范围只有 `<project>/.codebuddy/experience-reuse/experiences.json` 及其上一版 `.bak` 与临时写锁。查询不创建目录；首次 capture 才创建。所有记录在此项目内去重；find 不搜索其他项目、原生记忆目录、浏览器或网络。可共享的方法在获准后由原专业更新指定共享 Skill；工具没有自动发布到用户级的功能。

默认的项目记录含方法正文；已有权威来源时提供 `authority_ref`，不提供 `procedure`，工具保存引用和检索元数据，不复制原文。引用可指向当前任务的回执/说明、项目规则、配置或受控接口返回的本地证据文件；受控资产继续走原接口检索，不能用文件索引取代它。

## CLI

脚本路径见 SKILL.md。所有结果输出 JSON。`ok:false` 是错误，不能解释成无匹配。退出码 2 表示输入、损坏数据、写锁或路径失败。

- `status --project ROOT`：只读查看条目数与观察数。
- `find --project ROOT --query TEXT [--context-file FILE] [--limit 3]`：按词及精确上下文检索；limit 为 1–3。`when` 的键值与 context 精确比较；缺键只返回待补条件的线索，冲突、失效、证据缺失被分别列入 exclusions。用户仍须核对自然语言边界和权威原文。
- `capture --project ROOT --input FILE`：合并同 pattern_key；内容相同不重复写，改变则保存旧版并恢复 candidate，已有观察保留。工具不会因重复 capture 增加成功次数。
- `observe --project ROOT --input FILE [--revalidate]`：保存实际采用结果；event_key 幂等，同 key 不同内容报冲突。采用且条件核对后的 success 将 candidate 标为 validated；failure 将方法标为 stale。stale 再成功须显式 revalidate，retired/superseded 不自动复活。
- `mark --project ROOT --input FILE`：标记 stale、retired 或 superseded；替代项须为同项目已存在且未退役/替代的另一条。历史状态和证据保留。

### Capture 输入

```json
{
  "pattern_key": "site.example.detail.read",
  "summary": "示例：详情正文优先采用已验证的公开读取方法",
  "when": {"host": "example.com", "action": "read-detail", "tool": "example-reader"},
  "procedure": "示例方法文字；仅在已有实际观察时填写真实操作。",
  "success_check": "返回目标商品详情正文，并核对实体身份；页面壳不算成功。",
  "invalidate_when": "工具版本、页面类型或访问条件改变时重新核验。",
  "evidence_refs": ["/absolute/project/evidence/result.json"]
}
```

以上仅展示字段，不是已验证的站点方法。至少一份本地证据文件必须存在；路径存在仅证明可定位，不证明内容真实。`authority_ref` 模式用真实原文路径替代 `procedure`。证据正文由执行者实际检查，不由本工具推断。每条输入不超过 16 KiB，不保存整份聊天；证据只保留路径。

### Observe 输入

```json
{
  "id": "capture返回的ID",
  "event_key": "原任务ID.本轮.具体操作",
  "task_id": "原任务ID",
  "adopted": true,
  "conditions_checked": true,
  "outcome": "success",
  "evidence_refs": ["/absolute/project/evidence/result.json"],
  "note": "填写实际观察，不从退出码或模型自述推定业务成功。"
}
```

outcome 为 success/failure/inconclusive；未采用不计方法成功或失败。记录成功不等于正式规则 active，也不制造审批。一次操作在原任务有同样统计时，以原记录为统计来源，本索引只引用，不重复计算收益。

### Mark 输入

```json
{
  "id": "条目ID",
  "status": "stale",
  "reason": "实际发现的失效条件",
  "evidence_refs": ["/absolute/project/evidence/failure.json"]
}
```

superseded 时增加 `replacement_id`。条件变化不等于自动删除旧经验；失效条目默认不被推荐，但仍保留可追溯历史。

## 与原生记忆协作

优先使用本轮已注入的相关线索，按需读确切历史来源；不扫描或重建原生记忆。原生后台生成与新会话召回由宿主控制，本工具不劫持。需要给记忆留入口时，通过宿主现有协议记录规则 ID、范围与权威引用，避免复制整条可变规则；没有相关写权限就保留项目成果并如实说明。

项目正式晋级门优先。candidate/validated/stale 仅是经验观察状态，不替代所属项目的正式规则资格、专业职责、人工审核或费用授权。

## 隐私、并发与局限

工具拒绝原生记忆和其他 Agent 目录作为项目/证据目标，拒绝常见凭据文件及明显凭据内容；这只是辅助筛查，写入者仍须做隐私检查。记录不得包含网页注入的指令、登录材料或授权扩大。

写入使用独占锁、原子替换和上一版备份。锁已存在即失败，不删除未知锁；确认所属执行已结束后再由原维护者处理。记录绑定解析后的项目根目录，复制到别的项目会报错，禁止自动跨项目继承。损坏文件不覆盖、不从备份静默重建。

工具只核对结构、范围、上下文、来源可定位和历史状态，不证明语义正确或自动执行。当前 WorkBuddy 支持的用户/项目规则与 Skill 自动发现提供模型侧入口，不构成宿主工具拦截器。未覆盖的调用路径不宣称受到自动保护；新会话实际是否自动选择本 Skill 需另做真实任务验证。


## 重复工作触发修复

触发谓词和准确目录只读短路径以 SKILL.md 为唯一入口；此分支不自行追加记忆检索或建立索引。宿主更高优先级的原生记忆协议要求 quick pass 时须遵循并复用结果；不能用本 Skill 的短路径覆盖它。read_skill.py 接收任务实际给定的 --root alias=absolute-path 与 --reference alias/skill/SKILL.md，只解析已给根、检查越界并读取文件，返回解析来源与实际正文；失败不尝试猜路径。完整经验分支见 workflow.md。只读说明与禁止目标制作流程不排除此检查。无关单次读取不进入本 Skill。
