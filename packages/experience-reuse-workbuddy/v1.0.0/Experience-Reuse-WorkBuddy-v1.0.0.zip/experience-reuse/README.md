# Experience Reuse · WorkBuddy 迁移包

让已经做对的方法能在下一次相关行动前被采用，也保留新建 Skill 首次真实成功的条件与证据。已有原生记忆继续提供历史线索，具体经验留在所属项目。

## 安装

先在目标电脑 WorkBuddy 的“技能 → 添加技能 → 上传技能”导入此 ZIP，再把包内 INSTALL_PROMPT.txt 发给它。安装和触发配置见 [安装说明](references/workbuddy-setup.md)。不会自动安装到当前 Codex 或本机 WorkBuddy。

例如：上次处理过一批文件，新任务会先取回原方法、核对环境再处理新输入；新建业务 Skill 第一次就成功，也会在结果验证后保存首次成功经验。遇到版本或来源变化须重新核验，不机械套旧步骤。

## 依赖与边界

脚本需要 Python 3.10+，仅标准库，不需要 API Key、网络或其他 Skill。与 WorkBuddy 自身账户/模型计费保持独立；包内没有 Codex 登录态或订阅转移能力。只打包方法与合成测试，不携带个人经验、聊天、Cookie 或本机路径。

优先使用项目已有任务回执；可选索引位于项目 `.codebuddy/experience-reuse/experiences.json`。本版调整了索引位置及 WorkBuddy/CodeBuddy 生成记忆保护，保留原记录 schema 和 PN- ID 语义；不迁移旧库。

自动触发依赖 WorkBuddy 的实际技能发现、启用状态及规则加载。包通过离线测试不等于目标电脑已安装、用户级规则在全部办公任务中生效，或新会话自动复用已通过。原 Codex 的实测也不能替代 WorkBuddy 验收。

## 离线核验

```text
python -X utf8 -m unittest discover -s tests -v
python -X utf8 examples/demo.py
python -X utf8 scripts/verify_install.py
```

保留并查看本机实际输出。完整协同契约见 [integration](references/integration.md)，经验闭环见 [workflow](references/workflow.md)。
