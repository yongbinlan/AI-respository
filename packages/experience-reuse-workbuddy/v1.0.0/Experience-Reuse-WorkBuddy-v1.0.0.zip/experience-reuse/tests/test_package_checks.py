import importlib.util
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

script=Path(__file__).resolve().parents[1]/'scripts/verify_install.py'
spec=importlib.util.spec_from_file_location('package_check',script)
checker=importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


class PackageBehavior(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='experience-workbuddy-package-')
        self.root=Path(self.temp.name)/'experience-reuse'
        (self.root/'scripts').mkdir(parents=True)
        (self.root/'SKILL.md').write_text('synthetic test skill',encoding='utf-8')
        (self.root/'scripts/praxis.py').write_text('# synthetic test tool',encoding='utf-8')
        self.files=[{'path':str(p.relative_to(self.root)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in self.root.rglob('*') if p.is_file()]
        (self.root/'package-manifest.json').write_text(json.dumps({'schema_version':1,'files':self.files}),encoding='utf-8')

    def tearDown(self):self.temp.cleanup()

    def test_verification_writes_nothing_and_does_not_claim_host_activation(self):
        before={str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        result=checker.check(self.root)
        self.assertTrue(result['ok'])
        self.assertEqual(result['automatic_new_session_reuse'],'not_verified')
        self.assertEqual(before,{str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()})

    def test_missing_and_changed_files_are_reported(self):
        (self.root/'SKILL.md').write_text('changed',encoding='utf-8')
        (self.root/'scripts/praxis.py').unlink()
        result=checker.check(self.root)
        self.assertFalse(result['ok'])
        self.assertEqual({e['reason'] for e in result['errors']},{'missing','content_mismatch'})

    def test_unresolved_rule_fails_then_exact_target_rule_passes(self):
        rule=self.root.parent/'CODEBUDDY.md'
        text='<!-- experience-reuse:start -->\n<EXPERIENCE_REUSE_SKILL_MD>\n<!-- experience-reuse:end -->'
        rule.write_text(text,encoding='utf-8')
        self.assertFalse(checker.check(self.root,rule)['ok'])
        rule.write_text(text.replace('<EXPERIENCE_REUSE_SKILL_MD>',str(self.root/'SKILL.md')),encoding='utf-8')
        self.assertTrue(checker.check(self.root,rule)['ok'])


if __name__=='__main__':unittest.main(verbosity=2)
